"""
Init of rabbit_clients package

"""

from rabbit_clients.clients.blocking import PublishMessage, ConsumeMessage
